
public interface Botao {

}
