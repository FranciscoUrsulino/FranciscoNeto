
public interface Menu {

}
