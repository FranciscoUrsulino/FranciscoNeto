
public interface Janela {

}
