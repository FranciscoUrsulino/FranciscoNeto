
public interface FabricaAbstrata {
	Janela criaJanela();
	Menu criaMenu();
	Botao criaBotao();

}
