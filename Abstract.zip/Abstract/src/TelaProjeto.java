
public class TelaProjeto {

	private FabricaAbstrata fabrica;

	public void setFabrica() {
		
	}



	public void Montar() {
		// TODO Auto-generated method stub
		
	}

	public void Desenhar() {
		// TODO Auto-generated method stub
		
	}

	public void setFabrica(FabricaAbstrata fabrica) {
		this.fabrica = fabrica;
		// TODO Auto-generated method stub
		
	}

	
 
}
